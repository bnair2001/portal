import React from 'react'

const BasicPage = () => {
  return (
    <div>
      <h1>Basic Page</h1>
    </div>
  )
}

export default BasicPage
